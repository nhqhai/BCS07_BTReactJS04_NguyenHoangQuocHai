import React, { Component } from 'react';
import Carousel from './Carousel';
export default class Login extends Component {
  render() {
    return (
      <div>
        Login
        <Carousel />
      </div>
    );
  }
}
