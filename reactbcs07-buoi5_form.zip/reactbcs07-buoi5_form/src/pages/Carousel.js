import React, { Component } from 'react';

export default class Carousel extends Component {
  render() {
    return <div>Carousel</div>;
  }
}
