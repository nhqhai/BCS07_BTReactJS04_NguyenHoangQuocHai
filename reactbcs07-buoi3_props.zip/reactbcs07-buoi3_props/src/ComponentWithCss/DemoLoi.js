import React, { Component } from 'react';

export default class DemoLoi extends Component {
  render() {
    return <div className="demo">DemoLoi</div>;
  }
}
