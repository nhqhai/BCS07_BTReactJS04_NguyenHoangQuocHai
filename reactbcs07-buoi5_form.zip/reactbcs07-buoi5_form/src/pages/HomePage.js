import React, { Component } from 'react';

export default class HomePage extends Component {
  render() {
    return <div>HomePage</div>;
  }
}
